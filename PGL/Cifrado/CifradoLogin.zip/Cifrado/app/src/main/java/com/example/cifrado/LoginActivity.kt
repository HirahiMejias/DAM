package com.example.cifrado

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
//val palabraEncriptada = findViewById<TextView>(R.id.tvResultEncriptado)
        // val botonEncriptar = findViewById<Button>(R.id.btEncriptar)
        //        val botonDesencrip = findViewById<Button>(R.id.btDesencriptar)
        val NombreUsuario = findViewById<EditText>(R.id.etNombreUsuario)
        val Contrasenya = findViewById<EditText>(R.id.etContrasenya)
        val botonLogin = findViewById<Button>(R.id.btnLogin)
        val botonSignIn = findViewById<Button>(R.id.btnSignIn)
        val admin = AdminSQLiteOpenHelper(this, "administracion", null, 1)
        val db = admin.writableDatabase

        botonLogin.setOnClickListener {

        }

        botonSignIn.setOnClickListener {

        }
    }
}

