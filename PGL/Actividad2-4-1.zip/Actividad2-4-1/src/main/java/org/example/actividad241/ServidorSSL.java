package org.example.actividad241;

import javax.net.ssl.*;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.KeyStore;

public class ServidorSSL {
    private static final int PUERTO = 9878;
    private static final String ARCHIVO_BINARIO = "src/main/java/org/example/actividad241/miembros.dat";

    public static void main(String[] args) {
        try {
            // Configuración de SSL
            char[] password = "123456".toCharArray();
            KeyStore keyStore = KeyStore.getInstance("JKS");
            keyStore.load(new FileInputStream("src\\main\\java\\org\\example\\actividad241\\servidor.jks"), password);

            KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance("SunX509");
            keyManagerFactory.init(keyStore, password);

            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(keyManagerFactory.getKeyManagers(), null, null);

            SSLServerSocketFactory serverSocketFactory = sslContext.getServerSocketFactory();
            SSLServerSocket serverSocket = (SSLServerSocket) serverSocketFactory.createServerSocket(PUERTO);

            System.out.println("Servidor SSL iniciado en el puerto " + PUERTO);

            while (true) {
                try (SSLSocket socket = (SSLSocket) serverSocket.accept();
                     ObjectInputStream entrada = new ObjectInputStream(socket.getInputStream());
                     ObjectOutputStream salida = new ObjectOutputStream(socket.getOutputStream());
                     FileOutputStream fos = new FileOutputStream(ARCHIVO_BINARIO);
                     ObjectOutputStream oos = new ObjectOutputStream(fos)) {

                    // Leer objeto enviado por el cliente
                    MiembroGrupo miembro = (MiembroGrupo) entrada.readObject();
                    System.out.println("Objeto recibido: " + miembro);

                    // Guardar objeto en fichero binario
                    oos.writeObject(miembro);
                    oos.flush();

                    // Confirmar al cliente
                    salida.writeObject("Registro completado.");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
