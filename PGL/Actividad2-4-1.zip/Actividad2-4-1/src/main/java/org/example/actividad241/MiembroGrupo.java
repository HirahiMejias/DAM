package org.example.actividad241;

import java.io.Serializable;

// Clase MiembroGrupo: Representa los datos de un miembro del grupo
class MiembroGrupo implements Serializable {
    private String nombre;
    private String calle;
    private String ciudad;
    private String provincia;
    private String codigoPostal;

    public MiembroGrupo(String nombre, String calle, String ciudad, String provincia, String codigoPostal) {
        this.nombre = nombre;
        this.calle = calle;
        this.ciudad = ciudad;
        this.provincia = provincia;
        this.codigoPostal = codigoPostal;
    }

    @Override
    public String toString() {
        return "MiembroGrupo{" +
                "nombre='" + nombre + '\'' +
                ", calle='" + calle + '\'' +
                ", ciudad='" + ciudad + '\'' +
                ", provincia='" + provincia + '\'' +
                ", codigoPostal='" + codigoPostal + '\'' +
                '}';
    }
}
