package org.example.actividad241;

import java.io.*;
import java.security.cert.X509Certificate;
import javax.net.ssl.*;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

// Clase ClienteSSL: Envía objetos serializables al servidor
public class ClienteSSL extends Application {
    public static void main(String[] args) {
        launch(args);
    }
    private static final String HOST_SERVIDOR = "localhost";
    private static final int PUERTO_SERVIDOR = 9878;

    // Constructor sin argumentos
    public ClienteSSL() {
    }
    @Override
    public void start(Stage primaryStage) {
        VBox layout = new VBox(10);
        layout.setPadding(new javafx.geometry.Insets(10));

        TextField nombreField = new TextField();
        nombreField.setPromptText("Nombre");

        TextField calleField = new TextField();
        calleField.setPromptText("Calle");

        TextField ciudadField = new TextField();
        ciudadField.setPromptText("Ciudad");

        TextField provinciaField = new TextField();
        provinciaField.setPromptText("Provincia");

        TextField codigoPostalField = new TextField();
        codigoPostalField.setPromptText("Código Postal");

        Button enviarButton = new Button("Enviar");
        Label respuestaLabel = new Label();

        enviarButton.setOnAction(event -> {
            String nombre = nombreField.getText();
            String calle = calleField.getText();
            String ciudad = ciudadField.getText();
            String provincia = provinciaField.getText();
            String codigoPostal = codigoPostalField.getText();

            try {
                // Configuración de SSL
                System.setProperty("javax.net.ssl.trustStore", "src\\main\\java\\org\\example\\servidor.jks");
                System.setProperty("javax.net.ssl.trustStorePassword", "123456");
                TrustManager[] trustAllCerts = new TrustManager[]{
                        new X509TrustManager() {
                            public void checkClientTrusted(X509Certificate[] x509Certificates, String s) {
                            }

                            public void checkServerTrusted(X509Certificate[] x509Certificates, String s) {
                            }

                            public X509Certificate[] getAcceptedIssuers() {
                                return new X509Certificate[0];
                            }
                        }
                };
                SSLContext sslContext = SSLContext.getInstance("TLS");
                sslContext.init(null, trustAllCerts, null);

                SSLSocketFactory socketFactory = sslContext.getSocketFactory();
                try (SSLSocket socket = (SSLSocket) socketFactory.createSocket(HOST_SERVIDOR, PUERTO_SERVIDOR);
                     ObjectOutputStream salida = new ObjectOutputStream(socket.getOutputStream());
                     ObjectInputStream entrada = new ObjectInputStream(socket.getInputStream())) {

                    // Crear y enviar objeto
                    MiembroGrupo miembro = new MiembroGrupo(nombre, calle, ciudad, provincia, codigoPostal);
                    salida.writeObject(miembro);
                    salida.flush();
                    System.out.println("Objeto enviado al servidor.");

                    // Leer confirmación del servidor
                    String respuesta = (String) entrada.readObject();
                    respuestaLabel.setText("Respuesta del servidor: " + respuesta);
                }
            } catch (Exception e) {
                e.printStackTrace();
                respuestaLabel.setText("Error al enviar el objeto.");
            }
        });

        layout.getChildren().addAll(nombreField, calleField, ciudadField, provinciaField, codigoPostalField, enviarButton, respuestaLabel);

        Scene scene = new Scene(layout, 400, 300);
        primaryStage.setTitle("Cliente SSL");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

}
