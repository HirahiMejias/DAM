module org.example.actividad241 {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.actividad241 to javafx.fxml;
    exports org.example.actividad241;
}