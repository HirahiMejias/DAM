package Main;

import model.Alimento;
import model.Dieta;
import model.Usuario;
import org.hibernate.Session;
import org.hibernate.query.Query;
import java.util.List;

public class Consultas {

    public static void main(String[] args) {
        // Crear la sesión de Hibernate
        Session session = ConexionHibernate.getSession();

        // Consulta 1: Obtener todos los usuarios
        System.out.println("Consulta 1: Todos los usuarios");
        Query<Usuario> query1 = session.createQuery("from Usuario u", Usuario.class);
        List<Usuario> usuarios = query1.getResultList();
        for (Usuario usuario : usuarios) {
            System.out.println("ID: " + usuario.getId() + ", Nombre: " + usuario.getNombre() + ", Email: " + usuario.getEmail());
        }

        // Consulta 2: Obtener un usuario por nombre
        String nombreBuscado = "Hirahi";  // Nombre de ejemplo
        System.out.println("\nConsulta 2: Usuario con nombre '" + nombreBuscado + "'");
        Query<Usuario> query2 = session.createQuery("from Usuario u where u.nombre = :nombre", Usuario.class);
        query2.setParameter("nombre", nombreBuscado);
        List<Usuario> usuariosPorNombre = query2.getResultList();
        for (Usuario usuario : usuariosPorNombre) {
            System.out.println("ID: " + usuario.getId() + ", Nombre: " + usuario.getNombre() + ", Email: " + usuario.getEmail());
        }

        // Consulta 3: Obtener todas las dietas asociadas a un usuario (Ejemplo con ID = 1)
        int idUsuario = 1;
        System.out.println("\nConsulta 3: Dietas asociadas al usuario con ID " + idUsuario);
        Query<Dieta> query3 = session.createQuery("from Dieta d join d.usuario u where u.id = :idUsuario", Dieta.class);
        query3.setParameter("idUsuario", idUsuario);
        List<Dieta> dietas = query3.getResultList();
        for (Dieta dieta : dietas) {
            System.out.println("ID: " + dieta.getId() + ", Tipo: " + dieta.getTipo() + ", Descripción: " + dieta.getDescripcion());
        }

        // Consulta 4: Obtener dietas por descripción (Ejemplo con la palabra 'blanda')
        String descripcionBuscada = "DIETA";  // Descripción de ejemplo
        System.out.println("\nConsulta 4: Dietas con descripción que contenga '" + descripcionBuscada + "'");
        Query<Dieta> query4 = session.createQuery("from Dieta d where d.descripcion like :descripcion", Dieta.class);
        query4.setParameter("descripcion", "%" + descripcionBuscada + "%");
        List<Dieta> dietasPorDescripcion = query4.getResultList();
        for (Dieta dieta : dietasPorDescripcion) {
            System.out.println("ID: " + dieta.getId() + ", Tipo: " + dieta.getTipo() + ", Descripción: " + dieta.getDescripcion());
        }

        // Consulta 5: Obtener alimentos asociados a una dieta (Ejemplo con ID = 1)
        int idDieta = 1;
        System.out.println("\nConsulta 5: Alimentos asociados a la dieta con ID " + idDieta);
        Query<Object[]> query5 = session.createQuery(
                "select da.alimento, da.dieta from DietaAlimento da where da.dieta.id = :idDieta");
        query5.setParameter("idDieta", 1);
        List<Object[]> result = query5.getResultList();

        for (Object[] row : result) {
            Alimento alimento = (Alimento) row[0];
            Dieta dieta = (Dieta) row[1];
            System.out.println("Alimento: " + alimento.getNombre() + ", Dieta: " + dieta.getTipo());
        }


        // Cerrar la sesión de Hibernate
        session.close();
    }
}
