package model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "Usuario")
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String nombre;
    private String email;
    private String genero; // Masculino, Femenino, Otro
    private int edad;      // Edad del usuario
    private int calorias;  // Calorías asignadas al usuario
    private boolean tieneAlergias; // Indica si el usuario tiene alergias

    // Relaciones existentes
    @OneToMany(mappedBy = "usuario", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<Dieta> dietas = new ArrayList<>();

    @ManyToMany
    @JoinTable(
            name = "Usuario_Alimento",
            joinColumns = @JoinColumn(name = "usuario_id"),
            inverseJoinColumns = @JoinColumn(name = "alimento_id")
    )
    private Set<Alimento> alimentosFavoritos = new HashSet<>();

    // Getters y setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getGenero() { return genero; }
    public void setGenero(String genero) { this.genero = genero; }

    public int getEdad() { return edad; }
    public void setEdad(int edad) { this.edad = edad; }

    public int getCalorias() { return calorias; }
    public void setCalorias(int calorias) { this.calorias = calorias; }

    public boolean isTieneAlergias() { return tieneAlergias; }
    public void setTieneAlergias(boolean tieneAlergias) { this.tieneAlergias = tieneAlergias; }

    public List<Dieta> getDietas() { return dietas; }
    public void setDietas(List<Dieta> dietas) { this.dietas = dietas; }

    public Set<Alimento> getAlimentosFavoritos() { return alimentosFavoritos; }
    public void setAlimentosFavoritos(Set<Alimento> alimentosFavoritos) { this.alimentosFavoritos = alimentosFavoritos; }

    // Métodos para manejar Dieta
    public void addDieta(Dieta dieta) {
        dietas.add(dieta);
        dieta.setUsuario(this);
    }

    public void removeDieta(Dieta dieta) {
        dietas.remove(dieta);
        dieta.setUsuario(null);
    }
}


