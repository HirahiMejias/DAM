package model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "Alimento")
public class Alimento {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String nombre;
    private double calorias;

    @ManyToMany(mappedBy = "alimentosFavoritos")
    private Set<Usuario> usuarios = new HashSet<>();

    @OneToMany(mappedBy = "alimento", cascade = CascadeType.ALL)
    private Set<DietaAlimento> dietaAlimentos = new HashSet<>();

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getCalorias() {
        return calorias;
    }

    public void setCalorias(double calorias) {
        this.calorias = calorias;
    }

    public Set<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(Set<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    public Set<DietaAlimento> getDietaAlimentos() {
        return dietaAlimentos;
    }

    public void setDietaAlimentos(Set<DietaAlimento> dietaAlimentos) {
        this.dietaAlimentos = dietaAlimentos;
    }
}
