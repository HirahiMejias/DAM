package DAO;

import Main.ConexionHibernate;
import model.Dieta;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import java.util.List;

public class DietaDAO {
    private SessionFactory sessionFactory;



    public void create(Dieta dieta) {
        Transaction transaction = null;
        try (Session session = ConexionHibernate.getSession()) {
            transaction = session.beginTransaction();
            session.save(dieta);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    public Dieta findById(int id) {
        try (Session session = ConexionHibernate.getSession()) {
            return session.get(Dieta.class, id);
        }
    }

    public List<Dieta> findAll() {
        try (Session session = ConexionHibernate.getSession()) {
            return session.createQuery("FROM Dieta", Dieta.class).list();
        }
    }

    public void update(Dieta dieta) {
        Transaction transaction = null;
        try (Session session = ConexionHibernate.getSession()) {
            transaction = session.beginTransaction();
            session.update(dieta);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    public void delete(Dieta dieta) {
        Transaction transaction = null;
        try (Session session = ConexionHibernate.getSession()) {
            transaction = session.beginTransaction();
            session.delete(dieta);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }
}