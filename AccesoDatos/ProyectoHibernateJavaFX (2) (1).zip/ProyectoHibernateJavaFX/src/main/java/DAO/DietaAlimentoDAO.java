package DAO;
import Main.ConexionHibernate;
import model.DietaAlimento;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import java.util.List;

public class DietaAlimentoDAO {
    private SessionFactory sessionFactory;



    public void create(DietaAlimento dietaAlimento) {
        Transaction transaction = null;
        try (Session session = ConexionHibernate.getSession()) {
            transaction = session.beginTransaction();
            session.save(dietaAlimento);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    public DietaAlimento findById(int id) {
        try (Session session = ConexionHibernate.getSession()) {
            return session.get(DietaAlimento.class, id);
        }
    }

    public List<DietaAlimento> findAll() {
        try (Session session = ConexionHibernate.getSession()) {
            return session.createQuery("FROM DietaAlimento", DietaAlimento.class).list();
        }
    }

    public void update(DietaAlimento dietaAlimento) {
        Transaction transaction = null;
        try (Session session = ConexionHibernate.getSession()) {
            transaction = session.beginTransaction();
            session.update(dietaAlimento);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    public void delete(DietaAlimento dietaAlimento) {
        Transaction transaction = null;
        try (Session session = ConexionHibernate.getSession()) {
            transaction = session.beginTransaction();
            session.delete(dietaAlimento);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }
}

