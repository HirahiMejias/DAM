package DAO;

import model.Usuario;
import org.hibernate.Session;
import org.hibernate.Transaction;
import Main.ConexionHibernate;

import java.util.List;

public class UsuarioDAO {

    public void create(Usuario usuario) {
        Transaction transaction = null;
        try (Session session = ConexionHibernate.getSession()) {
            transaction = session.beginTransaction();
            session.save(usuario);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    public List<Usuario> findByName(String nombre) {
        try (Session session = ConexionHibernate.getSession()) {
            return session.createQuery("FROM Usuario WHERE nombre = :nombre", Usuario.class)
                    .setParameter("nombre", nombre)
                    .list();
        }
    }

    public List<Usuario> findAll() {
        try (Session session = ConexionHibernate.getSession()) {
            return session.createQuery("FROM Usuario", Usuario.class).list();
        }
    }

    public void update(Usuario usuario) {
        Transaction transaction = null;
        try (Session session = ConexionHibernate.getSession()) {
            transaction = session.beginTransaction();
            session.update(usuario);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    public void delete(Usuario usuario) {
        Transaction transaction = null;
        try (Session session = ConexionHibernate.getSession()) {
            transaction = session.beginTransaction();
            session.delete(usuario);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }
}
