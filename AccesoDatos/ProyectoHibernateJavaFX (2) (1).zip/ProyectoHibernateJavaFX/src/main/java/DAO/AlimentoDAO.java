package DAO;

import Main.ConexionHibernate;
import model.Alimento;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import java.util.List;

public class AlimentoDAO {


    public void create(Alimento alimento) {
        Transaction transaction = null;
        try (Session session = ConexionHibernate.getSession()) {
            transaction = session.beginTransaction();
            session.save(alimento);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    public Alimento findById(int id) {
        try (Session session = ConexionHibernate.getSession()) {
            return session.get(Alimento.class, id);
        }
    }

    public List<Alimento> findAll() {
        try (Session session = ConexionHibernate.getSession()) {
            return session.createQuery("FROM Alimento", Alimento.class).list();
        }
    }

    public void update(Alimento alimento) {
        Transaction transaction = null;
        try (Session session = ConexionHibernate.getSession()) {
            transaction = session.beginTransaction();
            session.update(alimento);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    public void delete(Alimento alimento) {
        Transaction transaction = null;
        try (Session session = ConexionHibernate.getSession()) {
            transaction = session.beginTransaction();
            session.delete(alimento);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }
}
