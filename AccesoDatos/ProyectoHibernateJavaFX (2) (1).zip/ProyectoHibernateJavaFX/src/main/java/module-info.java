module org.example.proyectohibernatejavafx {
    requires javafx.controls;
    requires javafx.fxml;
    requires jakarta.persistence;
    requires org.hibernate.orm.core;
    requires java.naming;
    requires java.sql;
    exports model;
    opens model;


    opens org.example.proyectohibernatejavafx to javafx.fxml;
    exports org.example.proyectohibernatejavafx;
}