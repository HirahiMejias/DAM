package org.example.proyectohibernatejavafx;


import DAO.AlimentoDAO;
import DAO.DietaAlimentoDAO;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;
import model.Alimento;
import model.Dieta;
import DAO.DietaDAO;
import model.DietaAlimento;
import model.Usuario;
import DAO.UsuarioDAO;

import java.util.List;

public class MainController {


@FXML private TextField textFieldId;
    @FXML private TextField textFieldNombre;
    @FXML private TextField textFieldEmail;
    @FXML private TextField textFieldTipoDieta;
    @FXML private TextField textFieldDescripcionDieta;
    @FXML private ComboBox<Usuario> comboBoxUsuarios;
    @FXML private ComboBox<Dieta> comboBoxDietas;
    @FXML private TableView<Usuario> tableViewUsuarios;
    @FXML private TableColumn<Usuario, Integer> columnId;
    @FXML private TableColumn<Usuario, String> columnNombre;
    @FXML private TableColumn<Usuario, String> columnEmail;
    @FXML private TableColumn<Usuario, String> columnGenero;
    @FXML private TableColumn<Usuario, Integer> columnEdad;
    @FXML private TableColumn<Usuario, Integer> columnCaloriasUsuario;
    @FXML private TableColumn<Usuario, Boolean> columnAlergias;

    @FXML
    private TableView<Dieta> tableViewDietas;
    @FXML
    private TableColumn<Dieta, Integer> columnIdDieta;
    @FXML
    private TableColumn<Dieta, String> columnTipoDieta;
    @FXML
    private TableColumn<Dieta, String> columnDescripcionDieta;
    @FXML
    private TableColumn<Dieta, String> columnUsuarios;
    @FXML private TextField textFieldNombreAlimento;
    @FXML private TextField textFieldCalorias;
    @FXML private TableView<Alimento> tableViewAlimentos;
    @FXML private TableColumn<Alimento, Integer> columnIdAlimento;
    @FXML private TableColumn<Alimento, String> columnNombreAlimento;
    @FXML private TableColumn<Alimento, Double> columnCalorias;

    @FXML private TableView<DietaAlimento> tableViewDietaAlimento;
    @FXML private TableColumn<DietaAlimento, Integer> columnIdDietaAlimento;
    @FXML private TableColumn<DietaAlimento, String> columnDieta;
    @FXML private TableColumn<DietaAlimento, String> columnAlimento;
    @FXML private TableColumn<DietaAlimento, Double> columnCantidad;

    @FXML private ComboBox<Alimento> comboBoxAlimentos;
    @FXML private TextField textFieldCantidad;

    @FXML
    private ToggleGroup toggleGroupGenero;

    @FXML
    private RadioButton radioButtonMasculino;

    @FXML
    private RadioButton radioButtonFemenino;

    @FXML
    private RadioButton radioButtonOtro;




    private ObservableList<DietaAlimento> dietaAlimentoData = FXCollections.observableArrayList();

    private DietaAlimentoDAO dietaAlimentoDAO = new DietaAlimentoDAO();

    private ObservableList<Alimento> alimentosData = FXCollections.observableArrayList();

    private AlimentoDAO alimentoDAO = new AlimentoDAO();

    private ObservableList<Dieta> dietasData = FXCollections.observableArrayList();

    private ObservableList<Usuario> usuariosData = FXCollections.observableArrayList();

    private UsuarioDAO usuarioDAO = new UsuarioDAO();
    private DietaDAO dietaDAO = new DietaDAO();

    @FXML
    public void initialize() {

        // Configuración inicial del Spinner para la edad
        SpinnerValueFactory<Integer> valueFactoryEdad =
                new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 120, 18);
        spinnerEdad.setValueFactory(valueFactoryEdad);

        // Initialize ToggleGroup for gender
        toggleGroupGenero = new ToggleGroup();
        radioButtonMasculino.setToggleGroup(toggleGroupGenero);
        radioButtonFemenino.setToggleGroup(toggleGroupGenero);
        radioButtonOtro.setToggleGroup(toggleGroupGenero);

        // Set user data for each RadioButton
        radioButtonMasculino.setUserData("Masculino");
        radioButtonFemenino.setUserData("Femenino");
        radioButtonOtro.setUserData("Otro");

        // Configuración inicial del Slider para las calorías
        sliderCalorias.setMin(500);  // Valor mínimo
        sliderCalorias.setMax(4000); // Valor máximo
        sliderCalorias.setValue(2000); // Valor inicial
        sliderCalorias.setShowTickLabels(true);
        sliderCalorias.setShowTickMarks(true);
        sliderCalorias.setMajorTickUnit(500);
        sliderCalorias.setBlockIncrement(100);
        // Configurar columnas de la tabla
        columnId.setCellValueFactory(new PropertyValueFactory<>("id"));
        columnNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        columnEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        columnGenero.setCellValueFactory(new PropertyValueFactory<>("genero"));
        columnEdad.setCellValueFactory(new PropertyValueFactory<>("edad"));
        columnCaloriasUsuario.setCellValueFactory(new PropertyValueFactory<>("calorias"));
        columnAlergias.setCellValueFactory(new PropertyValueFactory<>("tieneAlergias"));

        // Configurar columnas de la tabla de Dietas
        columnIdDieta.setCellValueFactory(new PropertyValueFactory<>("id"));
        columnTipoDieta.setCellValueFactory(new PropertyValueFactory<>("tipo"));
        columnDescripcionDieta.setCellValueFactory(new PropertyValueFactory<>("descripcion"));

        columnCalorias.setCellValueFactory(new PropertyValueFactory<>("calorias"));
        columnNombreAlimento.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        columnIdAlimento.setCellValueFactory(new PropertyValueFactory<>("id"));


        columnUsuarios.setCellValueFactory(cellData -> {
            Usuario usuario = cellData.getValue().getUsuario(); // Obtiene el usuario
            // Si el usuario es null, devolver un string vacío o algún valor predeterminado
            return new SimpleStringProperty(usuario != null ? String.valueOf(usuario.getId()) : "No asignado");
        });


        // Cargar los usuarios en el ComboBox
        usuariosData.addAll(usuarioDAO.findAll());  // Cargar los usuarios desde la base de datos
        comboBoxUsuarios.setItems(usuariosData);
        comboBoxUsuarios.setCellFactory(param -> new ListCell<Usuario>() {
            @Override
            protected void updateItem(Usuario usuario, boolean empty) {
                super.updateItem(usuario, empty);
                if (empty || usuario == null) {
                    setText(null);
                } else {
                    setText(usuario.getNombre());
                }
            }
        });


        // Cargar las dietas en el ComboBox
        dietasData.addAll(dietaDAO.findAll());  // Cargar las dietas desde la base de datos
        comboBoxDietas.setItems(dietasData);
        comboBoxDietas.setCellFactory(param -> new ListCell<Dieta>() {
            @Override
            protected void updateItem(Dieta dieta, boolean empty) {
                super.updateItem(dieta, empty);
                if (empty || dieta == null) {
                    setText(null);
                } else {
                    setText(dieta.getTipo());
                }
            }
        });


        // Configure ComboBox for Alimento
        comboBoxAlimentos.setCellFactory(param -> new ListCell<Alimento>() {
            @Override
            protected void updateItem(Alimento alimento, boolean empty) {
                super.updateItem(alimento, empty);
                if (empty || alimento == null) {
                    setText(null);
                } else {
                    setText(alimento.getNombre());
                }
            }
        });
        comboBoxAlimentos.setButtonCell(new ListCell<Alimento>() {
            @Override
            protected void updateItem(Alimento alimento, boolean empty) {
                super.updateItem(alimento, empty);
                if (empty || alimento == null) {
                    setText(null);
                } else {
                    setText(alimento.getNombre());
                }
            }
        });



        // Cargar los datos de las dietas y los usuarios en las tablas
        cargarUsuarios();
        cargarDietas();
        cargarAlimentos();
        cargarDietaAlimentos();
    }

    private void cargarUsuarios() {
        usuariosData.clear();
        usuariosData.addAll(usuarioDAO.findAll());
        tableViewUsuarios.setItems(usuariosData);
    }
    // Añadir Usuario
    @FXML
    private Spinner<Integer> spinnerEdad;
    @FXML
    private Slider sliderCalorias;
    @FXML
    private CheckBox checkBoxAlergias;
    @FXML
    private void handleAñadirUsuario() {
        // Configurar barra de progreso inicial
        progressBarOperacion.setProgress(0);

        String nombre = textFieldNombre.getText();
        String email = textFieldEmail.getText();
        String genero = toggleGroupGenero.getSelectedToggle() != null
                ? toggleGroupGenero.getSelectedToggle().getUserData().toString()
                : null; // Recuperar el valor seleccionado del ToggleGroup
        int edad = spinnerEdad.getValue(); // Recuperar la edad del Spinner
        int calorias = (int) sliderCalorias.getValue(); // Recuperar las calorías del Slider
        boolean tieneAlergias = checkBoxAlergias.isSelected(); // Recuperar el estado del CheckBox

        if (!nombre.isEmpty() && !email.isEmpty() && genero != null) {
            Usuario nuevoUsuario = new Usuario();
            nuevoUsuario.setNombre(nombre);
            nuevoUsuario.setEmail(email);
            nuevoUsuario.setGenero(genero);
            nuevoUsuario.setEdad(edad);
            nuevoUsuario.setCalorias(calorias);
            nuevoUsuario.setTieneAlergias(tieneAlergias);

            // Guardar el usuario en la base de datos
            usuarioDAO.create(nuevoUsuario);

            // Actualizar la tabla
            cargarUsuarios();
            progressBarOperacion.setProgress(100);
        } else {
            // Mostrar un mensaje de error si faltan datos obligatorios
           mostrarAlerta("Error","Por favor, completa todos los campos obligatorios.", Alert.AlertType.ERROR);
        }
    }


    @FXML
    private void handleEliminarUsuario() {
        Usuario usuarioSeleccionado = tableViewUsuarios.getSelectionModel().getSelectedItem();
        if (usuarioSeleccionado != null) {
            usuarioDAO.delete(usuarioSeleccionado);
            cargarUsuarios(); // Actualizar la tabla
        }
    }

    @FXML
    private void handleUsuarioSeleccionado() {
        Usuario usuarioSeleccionado = tableViewUsuarios.getSelectionModel().getSelectedItem();
        if (usuarioSeleccionado != null) {
            textFieldNombre.setText(usuarioSeleccionado.getNombre());
            textFieldEmail.setText(usuarioSeleccionado.getEmail());
        }
    }

    private void limpiarCampos() {
        textFieldNombre.clear();
        textFieldEmail.clear();
    }

    // MainController.java
    public void buscarUsuarios() {
        String nombreBuscado = textFieldNombre.getText().trim();

        if (!nombreBuscado.isEmpty()) {
            // Buscar usuarios por nombre utilizando el DAO
            List<Usuario> usuariosEncontrados = usuarioDAO.findByName(nombreBuscado);
            ObservableList<Usuario> usuariosFiltrados = FXCollections.observableArrayList(usuariosEncontrados);

            // Actualizar la tabla con los resultados
            tableViewUsuarios.setItems(usuariosFiltrados);
        } else {
            // Si no se ingresa texto, mostrar todos los usuarios
            List<Usuario> usuarios = usuarioDAO.findAll();
            ObservableList<Usuario> usuariosCompletos = FXCollections.observableArrayList(usuarios);
            tableViewUsuarios.setItems(usuariosCompletos);
        }
    }

    @FXML
    private ProgressBar progressBarOperacion;

    public void actualizarProgreso(double progreso) {
        if (progreso >= 0 && progreso <= 1) {
            progressBarOperacion.setProgress(progreso);
        }
    }



    @FXML
    private void handleActualizarUsuario() {
        Usuario usuarioSeleccionado = tableViewUsuarios.getSelectionModel().getSelectedItem();
        if (usuarioSeleccionado != null) {
            String nuevoNombre = textFieldNombre.getText();
            String nuevoEmail = textFieldEmail.getText();
            String nuevoGenero = toggleGroupGenero.getSelectedToggle() != null
                    ? toggleGroupGenero.getSelectedToggle().getUserData().toString()
                    : null;  // Recuperar el género seleccionado
            int nuevaEdad = spinnerEdad.getValue(); // Recuperar la edad del Spinner
            int nuevasCalorias = (int) sliderCalorias.getValue(); // Recuperar las calorías del Slider
            boolean tieneAlergias = checkBoxAlergias.isSelected(); // Recuperar el estado del CheckBox de alergias

            // Validar que los campos obligatorios no estén vacíos
            if (!nuevoNombre.isEmpty() && !nuevoEmail.isEmpty() && nuevoGenero != null) {
                // Actualizar los datos del usuario seleccionado
                usuarioSeleccionado.setNombre(nuevoNombre);
                usuarioSeleccionado.setEmail(nuevoEmail);
                usuarioSeleccionado.setGenero(nuevoGenero);
                usuarioSeleccionado.setEdad(nuevaEdad);
                usuarioSeleccionado.setCalorias(nuevasCalorias);
                usuarioSeleccionado.setTieneAlergias(tieneAlergias);

                // Actualizar en la base de datos
                usuarioDAO.update(usuarioSeleccionado);

                // Refrescar la tabla para mostrar los datos actualizados
                cargarUsuarios();

                // Limpiar los campos de entrada
                limpiarCampos();
            } else {
                // Mostrar un mensaje de error si faltan datos obligatorios
                mostrarAlerta("Por favor, completa todos los campos .","Error", Alert.AlertType.ERROR);
            }
        } else {
            mostrarAlerta("Error", "No se seleccionó ningún usuario", Alert.AlertType.ERROR);
        }
    }



    @FXML
    public void actualizarTablaUsuarios() {
        // Limpiar la tabla antes de añadir los nuevos datos
        tableViewUsuarios.getItems().clear();

        // Obtener los usuarios desde la base de datos (aquí debes usar tu DAO o método correspondiente)
        List<Usuario> usuarios = usuarioDAO.findAll();

        // Añadir los usuarios a la tabla
        tableViewUsuarios.getItems().addAll(usuarios);
    }

    @FXML
    public void actualizarTablaDietas() {
        // Limpiar la tabla antes de añadir los nuevos datos
        tableViewDietas.getItems().clear();

        // Obtener las dietas desde la base de datos (debes usar tu DAO o método correspondiente)
        List<Dieta> dietas = dietaDAO.findAll();

        // Añadir las dietas a la tabla
        tableViewDietas.getItems().addAll(dietas);
    }

    @FXML
    public void actualizarTablaAlimentos() {
        // Limpiar la tabla antes de añadir los nuevos datos
        tableViewAlimentos.getItems().clear();

        // Obtener los alimentos desde la base de datos (debes usar tu DAO o método correspondiente)
        List<Alimento> alimentos = alimentoDAO.findAll();

        // Añadir los alimentos a la tabla
        tableViewAlimentos.getItems().addAll(alimentos);
    }

    @FXML
    public void actualizarTablaDietasAlimento() {
        // Limpiar la tabla antes de añadir los nuevos datos
        tableViewDietaAlimento.getItems().clear();

        // Obtener las relaciones Dieta-Alimento desde la base de datos
        List<DietaAlimento> dietasAlimento = dietaAlimentoDAO.findAll();

        // Añadir las relaciones a la tabla
        tableViewDietaAlimento.getItems().addAll(dietasAlimento);
    }








    // Métodos CRUD para Dietas

    @FXML
    private void handleAñadirDieta() {
        String tipo = textFieldTipoDieta.getText();
        String descripcion = textFieldDescripcionDieta.getText();

        if (!tipo.isEmpty() && !descripcion.isEmpty()) {
            Dieta nuevaDieta = new Dieta();
            nuevaDieta.setTipo(tipo);
            nuevaDieta.setDescripcion(descripcion);
            dietaDAO.create(nuevaDieta); // Guardar la dieta en la base de datos
            mostrarAlerta("Operación Exitosa", "Dieta añadida correctamente", Alert.AlertType.INFORMATION);
            cargarDietas(); // Refrescar datos
            limpiarCamposDieta();
        } else {
            mostrarAlerta("Error", "Por favor, complete todos los campos", Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleActualizarDieta() {
        // Obtener la dieta seleccionada de la tabla
        Dieta dietaSeleccionada = tableViewDietas.getSelectionModel().getSelectedItem();

        if (dietaSeleccionada != null) {
            // Obtener los valores de los campos
            String nuevoTipo = textFieldTipoDieta.getText();
            String nuevaDescripcion = textFieldDescripcionDieta.getText();

            if (!nuevoTipo.isEmpty() && !nuevaDescripcion.isEmpty()) {
                // Actualizar los valores en el objeto dieta
                dietaSeleccionada.setTipo(nuevoTipo);
                dietaSeleccionada.setDescripcion(nuevaDescripcion);

                // Actualizar la dieta en la base de datos
                dietaDAO.update(dietaSeleccionada);

                // Mostrar mensaje de éxito
                mostrarAlerta("Operación Exitosa", "Dieta actualizada correctamente", Alert.AlertType.INFORMATION);

                // Refrescar la lista de dietas
                cargarDietas();

                // Limpiar los campos de entrada
                limpiarCamposDieta();
            } else {
                // Mostrar mensaje de error si los campos están vacíos
                mostrarAlerta("Error", "Por favor, complete todos los campos", Alert.AlertType.ERROR);
            }
        } else {
            // Mostrar mensaje de error si no se seleccionó una dieta
            mostrarAlerta("Error", "No se seleccionó ninguna dieta", Alert.AlertType.ERROR);
        }
    }



    @FXML
    private void handleEliminarDieta() {
        // Obtener la dieta seleccionada de la tabla
        Dieta dietaSeleccionada = tableViewDietas.getSelectionModel().getSelectedItem();

        if (dietaSeleccionada != null) {
            // Eliminar la dieta de la base de datos
            dietaDAO.delete(dietaSeleccionada);

            // Mostrar mensaje de éxito
            mostrarAlerta("Operación Exitosa", "Dieta eliminada correctamente", Alert.AlertType.INFORMATION);

            // Refrescar la lista de dietas
            cargarDietas();
        } else {
            // Mostrar mensaje de error si no se seleccionó una dieta
            mostrarAlerta("Error", "No se seleccionó ninguna dieta", Alert.AlertType.ERROR);
        }
    }




    // Métodos auxiliares
    private void cargarDietas() {
        dietasData.clear();
        dietasData.addAll(dietaDAO.findAll());
        tableViewDietas.setItems(dietasData);

    }

    private void limpiarCamposDieta() {
        textFieldTipoDieta.clear();
        textFieldDescripcionDieta.clear();
    }

    private void mostrarAlerta(String titulo, String mensaje, Alert.AlertType tipo) {
        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }




    @FXML
    private void handleAñadirRelacion() {
        Usuario selectedUsuario = comboBoxUsuarios.getSelectionModel().getSelectedItem();
        Dieta selectedDieta = comboBoxDietas.getSelectionModel().getSelectedItem();
        if (selectedUsuario != null && selectedDieta != null) {
            selectedUsuario.addDieta(selectedDieta); // Añadir relación
            usuarioDAO.update(selectedUsuario); // Actualizar entidad Usuario con las Dietas
            mostrarAlerta("Operación Exitosa", "Dieta asignada al usuario correctamente", Alert.AlertType.INFORMATION);
        } else {
            mostrarAlerta("Error", "Por favor, seleccione un usuario y una dieta", Alert.AlertType.ERROR);
        }
    }

    // Eliminar Relación (Usuario - Dieta)
    @FXML
    private void handleEliminarRelacion() {
        Usuario selectedUsuario = comboBoxUsuarios.getSelectionModel().getSelectedItem();
        Dieta selectedDieta = comboBoxDietas.getSelectionModel().getSelectedItem();
        if (selectedUsuario != null && selectedDieta != null) {
            selectedUsuario.removeDieta(selectedDieta); // Eliminar relación
            usuarioDAO.update(selectedUsuario); // Actualizar entidad Usuario
        }
    }

    @FXML
    private void handleAñadirAlimento() {
        String nombre = textFieldNombreAlimento.getText();
        String caloriasText = textFieldCalorias.getText();

        if (!nombre.isEmpty() && !caloriasText.isEmpty()) {
            double calorias = Double.parseDouble(caloriasText);

            Alimento nuevoAlimento = new Alimento();
            nuevoAlimento.setNombre(nombre);
            nuevoAlimento.setCalorias(calorias);

            alimentoDAO.create(nuevoAlimento); // Añadir el alimento a la base de datos
            cargarAlimentos(); // Actualizar la tabla
        }
    }

    @FXML
    private void handleActualizarAlimento() {
        Alimento alimentoSeleccionado = tableViewAlimentos.getSelectionModel().getSelectedItem();

        if (alimentoSeleccionado != null) {
            String nuevoNombre = textFieldNombreAlimento.getText();
            String nuevasCaloriasText = textFieldCalorias.getText();

            if (!nuevoNombre.isEmpty() && !nuevasCaloriasText.isEmpty()) {
                double nuevasCalorias = Double.parseDouble(nuevasCaloriasText);

                alimentoSeleccionado.setNombre(nuevoNombre);
                alimentoSeleccionado.setCalorias(nuevasCalorias);

                alimentoDAO.update(alimentoSeleccionado); // Actualizar el alimento en la base de datos
                cargarAlimentos(); // Actualizar la tabla
            }
        }
    }

    @FXML
    private void handleEliminarAlimento() {
        Alimento alimentoSeleccionado = tableViewAlimentos.getSelectionModel().getSelectedItem();

        if (alimentoSeleccionado != null) {
            alimentoDAO.delete(alimentoSeleccionado); // Eliminar el alimento de la base de datos
            cargarAlimentos(); // Actualizar la tabla
        }
    }

    private void cargarAlimentos() {

        alimentosData.clear();
        alimentosData.addAll(alimentoDAO.findAll());
        tableViewAlimentos.setItems(alimentosData);


    }

    @FXML
    private void handleAñadirDietaAlimento() {
        Dieta dietaSeleccionada = comboBoxDietas2.getSelectionModel().getSelectedItem();
        Alimento alimentoSeleccionado = comboBoxAlimentos.getSelectionModel().getSelectedItem();
        String cantidadStr = textFieldCantidad.getText();

        if (dietaSeleccionada != null && alimentoSeleccionado != null && !cantidadStr.isEmpty()) {
            double cantidad = Double.parseDouble(cantidadStr);

            DietaAlimento nuevaDietaAlimento = new DietaAlimento();
            nuevaDietaAlimento.setDieta(dietaSeleccionada);
            nuevaDietaAlimento.setAlimento(alimentoSeleccionado);
            nuevaDietaAlimento.setCantidad(cantidad);

            dietaAlimentoDAO.create(nuevaDietaAlimento);
            cargarDietaAlimentos(); // Actualizar la tabla
        } else {
            mostrarAlerta("Error", "Por favor, complete todos los campos", Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleActualizarDietaAlimento() {
        DietaAlimento dietaAlimentoSeleccionado = tableViewDietaAlimento.getSelectionModel().getSelectedItem();

        if (dietaAlimentoSeleccionado != null) {
            String cantidadStr = textFieldCantidad.getText();

            if (!cantidadStr.isEmpty()) {
                double cantidad = Double.parseDouble(cantidadStr);

                dietaAlimentoSeleccionado.setCantidad(cantidad);
                dietaAlimentoDAO.update(dietaAlimentoSeleccionado);
                cargarDietaAlimentos(); // Actualizar la tabla
            } else {
                mostrarAlerta("Error", "Por favor, complete todos los campos", Alert.AlertType.ERROR);
            }
        } else {
            mostrarAlerta("Error", "No se seleccionó ninguna relación Dieta-Alimento", Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleEliminarDietaAlimento() {
        DietaAlimento dietaAlimentoSeleccionado = tableViewDietaAlimento.getSelectionModel().getSelectedItem();

        if (dietaAlimentoSeleccionado != null) {
            dietaAlimentoDAO.delete(dietaAlimentoSeleccionado);
            cargarDietaAlimentos(); // Actualizar la tabla
        } else {
            mostrarAlerta("Error", "No se seleccionó ninguna relación Dieta-Alimento", Alert.AlertType.ERROR);
        }
    }
    @FXML private ComboBox<Dieta> comboBoxDietas2;

    private void cargarDietaAlimentos() {
        // Limpiar la lista observable antes de cargar nuevos datos
        dietaAlimentoData.clear();

        // Obtener la lista de Dieta-Alimento desde el DAO
        List<DietaAlimento> listaDietaAlimentos = dietaAlimentoDAO.findAll();

        // Obtener las listas de Dietas y Alimentos para los ComboBox
        List<Dieta> listaDietas = dietaDAO.findAll();
        List<Alimento> listaAlimentos = alimentoDAO.findAll();

        // Cargar las listas en los ComboBox
        ObservableList<Dieta> dietasObservableList = FXCollections.observableArrayList(listaDietas);
        comboBoxDietas2.setItems(dietasObservableList);

        // Configurar el ComboBox para que muestre solo el campo 'tipo' de cada Dieta
        comboBoxDietas2.setCellFactory(param -> new ListCell<Dieta>() {
            @Override
            protected void updateItem(Dieta item, boolean empty) {
                super.updateItem(item, empty);
                if (item != null) {
                    setText(item.getTipo());  // Muestra solo el 'tipo' de la Dieta
                } else {
                    setText(null);
                }
            }
        });

// Configurar cómo se verá el valor seleccionado en el ComboBox
        comboBoxDietas2.setButtonCell(new ListCell<Dieta>() {
            @Override
            protected void updateItem(Dieta item, boolean empty) {
                super.updateItem(item, empty);
                if (item != null) {
                    setText(item.getTipo());  // Muestra solo el 'tipo' al seleccionar
                } else {
                    setText(null);
                }
            }
        });

        ObservableList<Alimento> alimentosObservableList = FXCollections.observableArrayList(listaAlimentos);
        comboBoxAlimentos.setItems(alimentosObservableList);

        // Añadir los elementos a la lista observable de la tabla
        dietaAlimentoData.addAll(listaDietaAlimentos);

        // Configurar la tabla para mostrar los datos
        columnIdDietaAlimento.setCellValueFactory(new PropertyValueFactory<>("id"));
        columnDieta.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDieta().getTipo()));
        columnAlimento.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getAlimento().getNombre()));
        columnCantidad.setCellValueFactory(new PropertyValueFactory<>("cantidad"));

        // Asignar la lista observable a la tabla
        tableViewDietaAlimento.setItems(dietaAlimentoData);
    }


    @FXML
    private void handleLimpiar() {
        // Limpiar campos de texto
        textFieldNombre.clear();
        textFieldEmail.clear();
        textFieldCalorias.clear();
        textFieldNombreAlimento.clear();
        textFieldCantidad.clear();
        textFieldTipoDieta.clear();
        textFieldDescripcionDieta.clear();


        // Limpiar radio buttons (restablecer género)
        toggleGroupGenero.selectToggle(null);

        // Restablecer el slider de calorías
        sliderCalorias.setValue(2500); // Valor predeterminado

        // Restablecer el spinner de edad
        spinnerEdad.getValueFactory().setValue(25); // Edad predeterminada

        // Desmarcar el checkBox de alergias
        checkBoxAlergias.setSelected(false);


    }

    // Método para manejar la acción de "Salir"
    @FXML
    private void handleSalir() {
        // Cerrar la ventana o salir de la aplicación
        System.exit(0);
    }







}

