package org.example;

import model.Chapuza;
import model.Herramientas;
import model.Localizacion;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) throws ParseException {

//        anyadirChapuza();
//        modificarChapuza();
//        anyadirHerramienta();
//        anyadirHerramientasaChapuzas();
//        anyadirLugar();
//        asociarLugar();
//        borrarLugar();
//        borrarChapuzas();
//
//        Consulta1();
//        Consulta2();
//        Consulta3();

    }

    public static void anyadirChapuza() throws ParseException {

        Session session =ConexionHibernate.getSession();
        Transaction t = session.beginTransaction();

        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        Date date = formatter.parse("28-10-1999");
        Chapuza chapuza = new Chapuza();
        chapuza.setNombre("pepe");
        chapuza.setFechaNacimiento(date);
        chapuza.setAnyosExp(9);
        chapuza.setPrecioPorHora(40.5);
        session.persist(chapuza);


        t.commit();
        session.close();
    }

    public static void modificarChapuza(){
        Session session =ConexionHibernate.getSession();
        Transaction t = session.beginTransaction();

        Chapuza chapuza = session.get(Chapuza.class,1);
        chapuza.setNombre("Pepe Gotera");

        t.commit();
        session.close();
    }

    public static void anyadirHerramienta(){
        Session session =ConexionHibernate.getSession();
        Transaction t = session.beginTransaction();

        Herramientas h = new Herramientas();
        h.setNombre("taladro");
        h.setMarca("Dexter");
        h.setPrecio(70);
        session.persist(h);

        t.commit();
        session.close();
    }

   public static void anyadirHerramientasaChapuzas(){
       Session session =ConexionHibernate.getSession();
       Transaction t = session.beginTransaction();

       Chapuza pepe = session.get(Chapuza.class,1);
       Chapuza Hirahi = session.get(Chapuza.class,2);
       Herramientas amoladora = session.get(Herramientas.class,1);

       pepe.getHerramientas().add(amoladora);
       Hirahi.getHerramientas().add(amoladora);

       session.merge(pepe);
       session.merge(Hirahi);

       t.commit();
       session.close();
   }

   public static void anyadirLugar(){
       Session session =ConexionHibernate.getSession();
       Transaction t = session.beginTransaction();

       Localizacion l = new Localizacion();
       l.setNombre("CIFP Cesar Manrique");
       l.setDescripcion("Se ha ido la luz  no hay internet");

       session.persist(l);

       t.commit();
       session.close();
   }

   public static void asociarLugar(){
       Session session =ConexionHibernate.getSession();
       Transaction t = session.beginTransaction();

       Chapuza pepe = session.get(Chapuza.class,1);
       Chapuza Hirahi = session.get(Chapuza.class,2);
      Localizacion loc = session.get(Localizacion.class,1);

       pepe.setLocalizacion(loc);
       Hirahi.setLocalizacion(loc);

       session.merge(pepe);
       session.merge(Hirahi);

       t.commit();
       session.close();
   }

   public static void borrarLugar(){
       Session session =ConexionHibernate.getSession();
       Transaction t = session.beginTransaction();

       Localizacion loc = session.get(Localizacion.class,1);

       session.remove(loc);

       t.commit();
       session.close();
   }

   public static void borrarChapuzas(){
       Session session =ConexionHibernate.getSession();
       Transaction t = session.beginTransaction();

       Chapuza pepe = session.get(Chapuza.class,1);
       Chapuza Hirahi = session.get(Chapuza.class,2);

       session.remove(pepe);
       session.remove(Hirahi);

       t.commit();
       session.close();
   }

   public static void Consulta1(){
       Session session =ConexionHibernate.getSession();
       Transaction t = session.beginTransaction();

       ArrayList<Chapuza>chapuzas = (ArrayList<Chapuza>) session.createQuery("select c from Chapuza c where c.anyosExp < 15 and c.anyosExp >10").list();
       for (Chapuza chapuza : chapuzas){
           System.out.println(chapuza.toString());
       }

       t.commit();
       session.close();
   }

   public static void Consulta2(){
       Session session =ConexionHibernate.getSession();
       Transaction t = session.beginTransaction();

       String descripcion="reforma";

       ArrayList<Chapuza>chapuzas = (ArrayList<Chapuza>) session.createQuery("select c from Chapuza c where c.localizacion.descripcion like :descripcion")
               .setParameter("descripcion","%"+descripcion+"%").list();
       for (Chapuza chapuza : chapuzas){
           System.out.println(chapuza.toString());
       }

       t.commit();
       session.close();
   }

   public static void Consulta3(){
       Session session =ConexionHibernate.getSession();
       Transaction t = session.beginTransaction();


       ArrayList<Herramientas>herramientas = (ArrayList<Herramientas>) session.createQuery("select herramientas from Chapuza c where year (c.fechaNacimiento) > 2000").list();
       for (Herramientas herramienta : herramientas){
           System.out.println(herramienta.toString());
       }

       t.commit();
       session.close();
   }




}