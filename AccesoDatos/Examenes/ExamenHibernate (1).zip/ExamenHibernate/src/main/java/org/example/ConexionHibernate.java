package org.example;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class ConexionHibernate {
    private static ConexionHibernate instance = new ConexionHibernate();
    private static SessionFactory sessionFactory;

    private ConexionHibernate() {
        // Configura y construye el SessionFactory
        sessionFactory = new Configuration().configure().buildSessionFactory();
    }

    public static Session getSession() {
        return sessionFactory.openSession();
    }

    public void shutdown() {
        // Cierra caches y pools de conexiones
        sessionFactory.close();
    }
}
