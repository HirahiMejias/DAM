package model;

import jakarta.persistence.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.util.Date;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Table(name = "chapuza")
public class Chapuza {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_chapuza", nullable = false)
    private Integer id;

    @Column(name = "nombre", nullable = false)
    private String nombre;

    @Column(name = "fechaNacimiento", nullable = false)
    private Date fechaNacimiento;

    @Column(name = "PrecioPorHora", nullable = false)
    private Double precioPorHora;

    @Column(name = "anyosExp", nullable = false)
    private Integer anyosExp;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.SET_NULL)
    @JoinColumn(name = "id_localizacion")
    private Localizacion localizacion;

    @ManyToMany
    @JoinTable(
            name = "chapuzasHerramientas",
            joinColumns = @JoinColumn(name = "id_chapuza"),
            inverseJoinColumns = @JoinColumn(name = "id_herramienta")
    )
    private Set<Herramientas> herramientas = new LinkedHashSet<>();

    @Override
    public String toString() {
        return "Chapuza{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", fechaNacimiento=" + fechaNacimiento +
                ", precioPorHora=" + precioPorHora +
                ", anyosExp=" + anyosExp +
                ", localizacion=" + localizacion +
                ", herramientas=" + herramientas +
                '}';
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public Double getPrecioPorHora() {
        return precioPorHora;
    }

    public void setPrecioPorHora(Double precioPorHora) {
        this.precioPorHora = precioPorHora;
    }

    public Integer getAnyosExp() {
        return anyosExp;
    }

    public void setAnyosExp(Integer anyosExp) {
        this.anyosExp = anyosExp;
    }

    public Localizacion getLocalizacion() {
        return localizacion;
    }

    public void setLocalizacion(Localizacion localizacion) {
        this.localizacion = localizacion;
    }

    public Set<Herramientas> getHerramientas() {
        return herramientas;
    }

    public void setHerramientas(Set<Herramientas> herramientas) {
        this.herramientas = herramientas;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
