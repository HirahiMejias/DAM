package model;


import jakarta.persistence.*;
import jakarta.persistence.criteria.CriteriaBuilder;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Set;

@Entity
@Table(name = "localizacion")
public class Localizacion {
    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    private Integer id_localizacion;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "descripcion")
    private String descripcion;

    @OneToMany(mappedBy = "localizacion")
    private Set<Chapuza> chapuzas = new LinkedHashSet<>();

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Set<Chapuza> getChapuzas() {
        return chapuzas;
    }

    public void setChapuzas(Set<Chapuza> chapuzas) {
        this.chapuzas = chapuzas;
    }

    public void setId_localizacion(Integer idLocalizacion) {
        this.id_localizacion = idLocalizacion;
    }

    public Integer getId_localizacion() {
        return id_localizacion;
    }
}
