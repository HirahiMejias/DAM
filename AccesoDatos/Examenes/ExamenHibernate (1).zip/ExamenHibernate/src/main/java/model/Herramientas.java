package model;

import jakarta.persistence.*;

@Entity
@Table(name = "herramientas")
public class Herramientas {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_herramienta", nullable = false)
    private Integer id_herramienta;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "marca")
    private String marca;

    @Column(name="precio")
    private double precio;

    @Override
    public String toString() {
        return "Herramientas{" +
                "id_herramienta=" + id_herramienta +
                ", nombre='" + nombre + '\'' +
                ", marca='" + marca + '\'' +
                ", precio=" + precio +
                '}';
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Integer getId_herramienta() {
        return id_herramienta;
    }

    public void setId_herramienta(Integer id_herramienta) {
        this.id_herramienta = id_herramienta;
    }
}
