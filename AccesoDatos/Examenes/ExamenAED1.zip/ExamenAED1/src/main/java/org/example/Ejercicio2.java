package org.example;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Ejercicio2 {
    public static ArrayList<Persona> txtToArray(String txt) {
        ArrayList<Persona>personas = new ArrayList();
        try (BufferedReader br = new BufferedReader(new FileReader(txt))) { br.readLine();
            String linea=br.readLine();
            while (linea != null) {
                String[] datos =linea.split("\\|");
                Persona persona = new Persona(datos[0],datos[1],datos[2],Integer.parseInt(datos[3]),datos[4]);
                linea = br.readLine();
                System.out.println(persona.toString());
                personas.add(persona);
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return personas;
    }
    public static void arrayToXMl (ArrayList<Persona> personas) {
        DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();
        try{
            DocumentBuilder builder=factory.newDocumentBuilder();
            DOMImplementation dom=builder.getDOMImplementation();
            Document doc=dom.createDocument(null,"personas",null);
            doc.setXmlVersion("1.0");

            Element raiz=doc.getDocumentElement();
            Text texto= null;

            for (Persona persona : personas) {
                Element personaNodo=doc.createElement("persona");
                raiz.appendChild(personaNodo);

                Element Nombre=doc.createElement("nombre");
                personaNodo.appendChild(Nombre);
                Nombre.appendChild(doc.createTextNode(persona.getNombre()));

                Element Apellido1=doc.createElement("apellido1");
                personaNodo.appendChild(Apellido1);
                Apellido1.appendChild(doc.createTextNode(persona.getApellido1()));

                Element Apellido2=doc.createElement("apellido2");
                personaNodo.appendChild(Apellido2);
                Apellido2.appendChild(doc.createTextNode(persona.getApellido2()));

                Element Edad=doc.createElement("edad");
                personaNodo.appendChild(Edad);
                Edad.appendChild(doc.createTextNode(String.valueOf(persona.getEdad())));

                Element Sexo = doc.createElement("sexo");
                personaNodo.appendChild(Sexo);
                Sexo.appendChild(doc.createTextNode(persona.getSexo()));

            }
            Source source = new DOMSource(doc);
            Result result = new StreamResult(new java.io.File("src/ficheros/personas.xml"));
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.transform(source,result);
        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        } catch (TransformerConfigurationException e) {
            throw new RuntimeException(e);
        } catch (TransformerException e) {
            throw new RuntimeException(e);
        }
    }
}
