package org.example;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Ejercicio1 {

    private static ArrayList<FileExtensionesClass>extensiones = new ArrayList();
    private static int contadorDir=0;
    public static void procesarDir(File dir) {

        if (dir.isDirectory()) {
            contadorDir++;
            File[] files = dir.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isDirectory()) {
                        procesarDir(file);
                    } else {
                        procesarFile(file);
                    }
                }
            }
        }
    }

    private static void procesarFile(File file) {
        String fileName = file.getName();
        String extension = "";

        int i = fileName.lastIndexOf('.');
        if (i > 0) {
            extension = fileName.substring(i + 1).toLowerCase();
        }

        if (!extension.isEmpty()) {
            añadirExtension(extension);
        }
    }

    private static void añadirExtension(String extension) {

        boolean encontrado = false;
        for (FileExtensionesClass fileExt : extensiones) {
            if (fileExt.getExtension().equals(extension)) {
                fileExt.incrementaCuenta();
                encontrado = true;
                break;
            }
        }

        if (!encontrado) {
            extensiones.add(new FileExtensionesClass(extension));
        }
    }

    public static void mostrar() {
        System.out.println("Numero de Directorios:"+contadorDir);
        for (FileExtensionesClass fileExt : extensiones) {
            System.out.println("Extension: " + fileExt.getExtension() + ":" + fileExt.getCuenta());
        }

    }
}















