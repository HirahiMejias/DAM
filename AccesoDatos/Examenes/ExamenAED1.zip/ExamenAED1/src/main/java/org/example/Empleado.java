package org.example;

public class Empleado {

    private int Id;
    private String Apellido;
    private int Departamento;
    private Double salario;

    public Empleado(String apellido, Double salario, int departamento, int id) {
        this.Apellido = apellido;
        this.salario = salario;
        this.Departamento = departamento;
        this.Id = id;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String apellido) {
        Apellido = apellido;
    }

    public int getDepartamento() {
        return Departamento;
    }

    public void setDepartamento(int departamento) {
        Departamento = departamento;
    }

    public Double getSalario() {
        return salario;
    }

    public void setSalario(Double salario) {
        this.salario = salario;
    }

    @Override
    public String toString() {
        return "Empleado{" +
                "Id=" + Id +
                ", Apellido='" + Apellido + '\'' +
                ", Departamento=" + Departamento +
                ", salario=" + salario +
                '}';
    }
}
