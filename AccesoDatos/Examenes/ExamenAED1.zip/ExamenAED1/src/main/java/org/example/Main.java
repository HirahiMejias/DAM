package org.example;

import java.io.File;
import java.util.ArrayList;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
//    ArrayList<Persona> personas = Ejercicio2.txtToArray("src/ficheros/ejecicio2.txt");
//    Ejercicio2.arrayToXMl(personas);
   File dir = new File("src/MiDir");
        Ejercicio1.procesarDir(dir);
        Ejercicio1.mostrar();
   //Ejercicio3.devuelveEmpleado(0);
    }
}