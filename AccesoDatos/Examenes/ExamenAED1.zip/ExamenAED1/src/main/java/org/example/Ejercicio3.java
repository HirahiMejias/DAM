package org.example;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
/*

 */
public class Ejercicio3 {
    public static Empleado devuelveEmpleado(int posicion) {

        try(RandomAccessFile raf =new RandomAccessFile(new File("empleados.dat"),"rw");){
            int TamanyoObj = (4 * 5 * 2 );
            long numRegistros = raf.length() / TamanyoObj;
            for (int i = 0; i < numRegistros; i++) {
                for (int j = 0; j < TamanyoObj; j++) {
                    raf.seek((i * TamanyoObj));
                }
            }

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return null;
    }


}
