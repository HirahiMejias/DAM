/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PaqueteExamen;

/**
 *
 * @author Friedrich
 */
public class Campo {
    private String Nombre;
    private String Tipo;
    private boolean Nulos;
    private int tamanio;
    public Campo(){
    
    }
    
    public Campo(String Nombre, String Tipo, boolean Nulos, int tamanio){
        this.Nombre = Nombre;
        this.Tipo= Tipo;
        this.Nulos= Nulos;
        this.tamanio= tamanio;
    }
    
    /**
     * @return the Nombre
     */
    public String getNombre() {
        return Nombre;
    }

    /**
     * @param Nombre the Nombre to set
     */
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    /**
     * @return the Tipo
     */
    public String getTipo() {
        return Tipo;
    }

    /**
     * @param Tipo the Tipo to set
     */
    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }

    /**
     * @return the Nulos
     */
    public boolean isNulos() {
        return Nulos;
    }

    /**
     * @param Nulos the Nulos to set
     */
    public void setNulos(boolean Nulos) {
        this.Nulos = Nulos;
    }

    /**
     * @return the tamanio
     */
    public int getTamanio() {
        return tamanio;
    }

    /**
     * @param tamanio the tamanio to set
     */
    public void setTamanio(int tamanio) {
        this.tamanio = tamanio;
    }
    

}
