package org.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Transacciones {
    public static void transaccion() throws SQLException {
      Connection connection = Conexion.getConexion();
      String sql = "Insert into departamentos values(50,'DOCENCIA','TENERIFE')";
      String sql2 = "Insert into empleados VALUES (6666,'SUPER LOPEZ',50)";

      try {
          connection.setAutoCommit(false);

          PreparedStatement ps = connection.prepareStatement(sql);
          ps.execute(sql);

          PreparedStatement ps2 = connection.prepareStatement(sql2);
          ps2.execute(sql2);
          connection.commit();
          System.out.println("Transaccion Completada");
      } catch (SQLException e) {
          connection.rollback();
          System.out.println("transaccion no completada rollback");
          throw new RuntimeException(e);
      }


    }
}
