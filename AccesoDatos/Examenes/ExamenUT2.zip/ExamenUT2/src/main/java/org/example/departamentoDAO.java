package org.example;

import java.util.ArrayList;
import java.util.List;

public interface departamentoDAO {

    void anyadir(Departamento departamento);

    void borrar(Integer id);

    void update(Integer id,Departamento departamento);

    void leer(Integer id);

    //List<Departamento> leerTodos();

}
