package org.example;

import java.sql.SQLException;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) throws SQLException {
//       Transacciones.transaccion();

       departamentoDAOMYSQL dao = new departamentoDAOMYSQL();

//       Departamento nuevoDepar = new Departamento(77,"pepemel","la esperanza");
//       dao.anyadir(nuevoDepar);
//        Departamento updateDepar = new Departamento(78,"elbolichozooo","ofra");
//       dao.update(78,updateDepar);
       dao.leer(78);


    }
}