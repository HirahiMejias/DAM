package org.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class departamentoDAOMYSQL implements departamentoDAO{
    Connection connection = Conexion.getConexion();
    @Override
    public void anyadir(Departamento departamento) {
        String sql = "Insert into departamentos VALUES (?,?,?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)){
            ps.setInt(1,departamento.id);
            ps.setString(2,departamento.dnombre);
            ps.setString(3,departamento.loc);
            ps.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void borrar(Integer id) {
        String sql = "delete from departamentos Where dept_no=?";
        try (PreparedStatement ps = connection.prepareStatement(sql)){
            ps.setInt(1,id);
            ps.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void update(Integer id, Departamento departamento) {
        String sql = "update departamentos set dept_no=?,dnombre=?,loc=? Where dept_no=? ";
        try (PreparedStatement ps = connection.prepareStatement(sql)){
            ps.setInt(1,departamento.id);
            ps.setString(2,departamento.dnombre);
            ps.setString(3,departamento.loc);
            ps.setInt(4,id);
            ps.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void leer(Integer id) {
        String sql = "Select * from Departamentos where dept_no=?";
        try (PreparedStatement ps = connection.prepareStatement(sql)){
            ps.setInt(1,id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()){
                 Departamento dept=new Departamento(rs.getInt("dept_no"), rs.getString("dnombre"), rs.getString("loc"));
                System.out.println(dept);

            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

//    @Override
//    public List<Departamento> leerTodos() {
//        List<Departamento>listaDept = new ArrayList<>();
//            String query = "Select * from Departamentos";
//            try (PreparedStatement ps = connection.prepareStatement(query)){
//                ResultSet rs = ps.executeQuery();
//                while (rs.next()){
//                    listaDept.add(new Departamento((rs.getInt("dept_no"),rs.getString("dnombre"),rs.getString("loc"));
//                }
//            } catch (SQLException e) {
//                throw new RuntimeException(e);
//            }
//        return listaDept;

    }


//}
