package org.example;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Metadata {
    public void sacarmetadata() throws SQLException {
        Connection connection = Conexion.getConexion();
        DatabaseMetaData metaDatos=connection.getMetaData();
        ResultSet rs = metaDatos.getTables("nba",null,null,null);



    }
}
